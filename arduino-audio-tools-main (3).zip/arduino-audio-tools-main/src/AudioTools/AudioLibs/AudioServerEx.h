#pragma once
#warning("obsolete: use AudioTools/Communication/AudioServerEx.h")
#include "AudioTools/Communication/AudioServerEx.h"