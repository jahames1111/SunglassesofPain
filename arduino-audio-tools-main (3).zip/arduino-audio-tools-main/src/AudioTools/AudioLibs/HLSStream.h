#pragma once
#WARNING("Obsolete - use /AudioTools/Communication/HLSStream.h")
#include "AudioTools/Communication/HLSStream.h"