#pragma once
#WARNING("Obsolete: Use AudioTools/Communication/AudioClientRTSP555.h")
#include "AudioTools/Communication/AudioClientRTSP555.h"