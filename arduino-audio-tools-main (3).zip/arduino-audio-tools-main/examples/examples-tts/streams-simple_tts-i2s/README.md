# Simple TTS

I am providing a simple sketch which generates sound data with my Simple TTS text to speach engine that 
uses a configurable library of prerecorded words.

You need to install https://github.com/pschatzmann/arduino-simple-tts

In this demo we provide the result as I2SStream but you can easly replace with any other output stream. 

More examples can be found at https://github.com/pschatzmann/arduino-simple-tts/tree/main/examples

## External DAC

for defails see the [Wiki](https://github.com/pschatzmann/arduino-audio-tools/wiki/External-DAC)