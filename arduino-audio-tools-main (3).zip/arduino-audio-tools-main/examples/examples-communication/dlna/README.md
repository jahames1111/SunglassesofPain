
Further DLNA examples that do not depend on the AudioTools can be found in the [arduino-dlna/examples](https://github.com/pschatzmann/arduino-dlna/tree/main/examples)!